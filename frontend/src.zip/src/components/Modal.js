import React from 'react'

const Modal = () => {
  return (
    <div>
      
    </div>
  )
}

export default Modal
